package vn.viettuts.qlsv.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Optional;

import vn.viettuts.qlsv.dao.UserDao;
import vn.viettuts.qlsv.entity.User;
import vn.viettuts.qlsv.view.LoginView;
import vn.viettuts.qlsv.view.MainView;

import javax.swing.*;

public class LoginController {
    private final UserDao userDao;
    private final LoginView loginView;
    private final MainView mainView;


    public LoginController(LoginView view) {
        this.loginView = view;
        this.userDao = new UserDao();
        this.mainView = new MainView();

        loginView.setBtnLogin(new LoginListener());
        loginView.setBtnDispose(new DisposeListener());
    }

    public void showLoginView() {
        loginView.setVisible(true);
    }

    class LoginListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            Optional<User> user = Optional.ofNullable(loginView.getUser());

            if (userDao.checkUser(user.orElse(new User()))) {
                JOptionPane.showMessageDialog(loginView, "Đăng nhập thành công");

                MainViewController mainViewController = new MainViewController(mainView);
                mainViewController.showMainView();

                loginView.dispose();
            } else {
                JOptionPane.showMessageDialog(loginView, "Sai tên đăng nhập hoặc mật khẩu");
            }
        }
    }

    class DisposeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            loginView.dispose();
        }
    }
}
