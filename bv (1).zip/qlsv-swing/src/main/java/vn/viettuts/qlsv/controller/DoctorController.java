package vn.viettuts.qlsv.controller;

import vn.viettuts.qlsv.dao.DoctorDao;
import vn.viettuts.qlsv.entity.Doctor;
import vn.viettuts.qlsv.utils.Regex;
import vn.viettuts.qlsv.view.DoctorView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class DoctorController {
    private final DoctorView doctorView;
    private final DoctorDao doctorDao;

    public DoctorController(DoctorView doctorView) {
        this.doctorView = doctorView;
        this.doctorDao = new DoctorDao();

        doctorView.setTableData(doctorDao.getDoctorList());
        doctorView.setDoctorId(doctorDao.getDoctorList().size());

        // add listeners
        this.doctorView.setBtnAdd(new AddButtonListener());
        this.doctorView.setBtnUpdate(new UpdateButtonListener());
        this.doctorView.setBtnDelete(new DeleteButtonListener());
        this.doctorView.setSearch(new SearchButtonListener());
        this.doctorView.setBtnRefresh(new RefreshButtonListener());

    }

    private boolean validInput(Doctor doctor) {
        if (!Regex.isMatch("email", doctor.getEmail())) {
            JOptionPane.showMessageDialog(doctorView, "Email không hợp lệ");
            return true;
        }

        if (!Regex.isMatch("phone", doctor.getPhone())) {
            JOptionPane.showMessageDialog(doctorView, "Số điện thoại không hợp lệ");
            return true;
        }

        if (!Regex.isMatch("date", doctor.getDob())) {
            JOptionPane.showMessageDialog(doctorView, "Ngày sinh không hợp lệ(dd-MM-yyyy)");
            return true;
        }
        return false;
    }

    class AddButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("Add button clicked");
            Optional<Doctor> doctor = Optional.ofNullable(doctorView.getDoctor());

            if (doctor.isPresent()) {
                if (validInput(doctor.get())) {
                    return;
                }

                try {
                    doctorDao.add(doctor.get());
                    doctorView.setTableData(doctorDao.getDoctorList());
                    JOptionPane.showMessageDialog(doctorView, "Thêm bác sĩ thành công");
                    doctorView.clear(doctorDao.getDoctorList().size());
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(doctorView, ex.getMessage());
                }

            } else {
                JOptionPane.showMessageDialog(doctorView, "Vui lòng nhập đầy đủ thông tin");
            }

        }
    }


    class UpdateButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Optional<Doctor> doctor = Optional.ofNullable(doctorView.getDoctor());

            if (doctor.isPresent()) {
                if (validInput(doctor.get())) {
                    return;
                }

                try {
                    doctorDao.update(doctor.get());
                    doctorView.setTableData(doctorDao.getDoctorList());
                    JOptionPane.showMessageDialog(doctorView, "Cập nhật bác sĩ thành công");
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(doctorView, ex.getMessage());
                }
            } else {
                JOptionPane.showMessageDialog(doctorView, "Vui lòng chọn bác sĩ cần cập nhật");
            }
        }
    }

    class DeleteButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Optional<Doctor> doctor = Optional.ofNullable(doctorView.getDoctor());

            if (doctor.isPresent()) {
                int input = JOptionPane.showConfirmDialog(doctorView, "Bạn có chắc chắn muốn xóa bác sĩ này không?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
                if (input == 0) {
                    doctorDao.delete(doctor.get());
                    doctorView.setTableData(doctorDao.getDoctorList());
                    JOptionPane.showMessageDialog(doctorView, "Xóa bác sĩ thành công");
                }
            } else {
                JOptionPane.showMessageDialog(doctorView, "Vui lòng chọn bác sĩ cần xóa");
            }
        }
    }

    class SearchButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Map<String, String> searchCriteria = doctorView.getSearchCriteria();
            List<Doctor> doctors = doctorDao.searchDoctors(searchCriteria);
            doctorView.setTableData(doctors);
        }
    }

    class RefreshButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            doctorView.clear(doctorDao.getDoctorList().size());
            doctorView.setTableData(doctorDao.getDoctorList());
        }
    }
}
