package vn.viettuts.qlsv.entity.wrapper;

import vn.viettuts.qlsv.entity.Schedule;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "schedules")
@XmlAccessorType(XmlAccessType.FIELD)
public class ScheduleXML {
    @XmlElement(name = "schedule")
    private List<Schedule> scheduleList;

    public List<Schedule> getScheduleList() {
        return scheduleList;
    }

    public void setScheduleList(List<Schedule> scheduleList) {
        this.scheduleList = scheduleList;
    }
}
