package vn.viettuts.qlsv.dao;

import vn.viettuts.qlsv.entity.Patient;
import vn.viettuts.qlsv.entity.wrapper.PatientXML;
import vn.viettuts.qlsv.utils.FileUtils;
import vn.viettuts.qlsv.utils.InitDb;

import java.util.*;
import java.util.stream.Collectors;

public class PatientDao {
    private final String FILE_PATH = "src/main/resources/data/patients.xml";

//    private final String FILE_PATH = InitDb.getFilePath("patients.xml");

    private List<Patient> patients;


    public PatientDao() {
        this.patients = readListPatients();
        if (patients == null) {
            patients = new ArrayList<>();
        }
        System.out.println(patients);
    }

    public List<Patient> getPatients() {
        patients.sort(Comparator.comparing(Patient::getId));
        return patients;
    }

    private List<Patient> readListPatients() {
        List<Patient> list = new ArrayList<>();
        PatientXML patientXML = (PatientXML) FileUtils.readXMLFile(FILE_PATH, PatientXML.class);
        if (patientXML != null) {
            list = patientXML.getPatients();
        }
        return list;
    }

    private void writeListPatients(List<Patient> patients) {
        PatientXML patientXML = new PatientXML();
        patientXML.setPatients(patients);
        FileUtils.writeXMLtoFile(FILE_PATH, patientXML);
    }

    private boolean isExistPhone(Patient patientToCheck, boolean isUpdate) {
        for (Patient patient : patients) {
            if (isUpdate && patient.getId().equals(patientToCheck.getId())) {
                continue;
            }

            if (patient.getPhone().equals(patientToCheck.getPhone()) || patient.getId().equals(patientToCheck.getId())) {
                return true;
            }
        }
        return false;
    }


    public void add(Patient patient) throws IllegalArgumentException {
        if (isExistPhone(patient, false)) {
            throw new IllegalArgumentException("Số điện thoại đã tồn tại hoặc mã đã tồn tại");
        }

        patients.add(patient);
        writeListPatients(patients);
    }

    public void update(Patient patient) {
        if (isExistPhone(patient, true)) {
            throw new IllegalArgumentException("Số điện thoại đã tồn tại hoặc mã đã tồn tại");

        }
        for (Patient p : patients) {
            if (Objects.equals(p.getId(), patient.getId())) {
                patients.set(patients.indexOf(p), patient);
                break;
            }
        }
        writeListPatients(patients);
    }

    public void delete(Patient patientToDelete) {
        patients.removeIf(patient -> Objects.equals(patient.getId(), patientToDelete.getId()));
        writeListPatients(patients);
    }

    public List<Patient> searchPatient(Map<String, String> criteria) {
        return patients.stream().filter(patient -> {
            boolean matched = true;
            for (Map.Entry<String, String> entry : criteria.entrySet()) {
                switch (entry.getKey()) {
                    case "id":
                        matched = patient.getId().contains(entry.getValue());
                        break;
                    case "name":
                        matched = patient.getName().toLowerCase().contains(entry.getValue().toLowerCase());
                        break;
                    case "phone":
                        matched = patient.getPhone().toLowerCase().contains(entry.getValue().toLowerCase());
                        break;
                    case "dob":
                        matched = patient.getDob().toLowerCase().contains(entry.getValue().toLowerCase());
                        break;
                    case "gender":
                        matched = patient.getGender().toLowerCase().contains(entry.getValue().toLowerCase());
                        break;
                    case "address":
                        matched = patient.getAddress().toLowerCase().contains(entry.getValue().toLowerCase());
                        break;
                    case "medicalHistory":
                        matched = patient.getMedicalHistory().toLowerCase().contains(entry.getValue().toLowerCase());
                        break;
                    default:
                        matched = false;
                }
                if (!matched) {
                    break;
                }
            }
            return matched;
        }).collect(Collectors.toList());
    }

    public List<String> getAllPatientIds() {
        List<String> patientIds = new ArrayList<>();
        for (Patient patient : patients) {
            patientIds.add(patient.getId());
        }
        patientIds.sort(Comparator.naturalOrder());
        return patientIds;
    }
}
