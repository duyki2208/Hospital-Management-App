package vn.viettuts.qlsv.entity.wrapper;

import vn.viettuts.qlsv.entity.Doctor;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "doctors")
@XmlAccessorType(XmlAccessType.FIELD)
public class DoctorXML {
    @XmlElement(name = "doctor")
    private List<Doctor> doctors;

    public List<Doctor> getDoctors() {
        return doctors;
    }

    public void setDoctors(List<Doctor> doctors) {
        this.doctors = doctors;
    }
}
