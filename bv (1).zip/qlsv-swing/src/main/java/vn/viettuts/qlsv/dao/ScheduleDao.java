package vn.viettuts.qlsv.dao;

import vn.viettuts.qlsv.entity.Schedule;
import vn.viettuts.qlsv.entity.wrapper.ScheduleXML;
import vn.viettuts.qlsv.utils.FileUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class ScheduleDao {
    private final String FILE_PATH = "src/main/resources/data/schedules.xml";
    private List<Schedule> scheduleList;

    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
    private static final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");

    public ScheduleDao() {
        this.scheduleList = readListSchedules();
        if (scheduleList == null) {
            scheduleList = new ArrayList<>();
        }

        System.out.println("ScheduleDao: " + scheduleList);
    }

    public List<Schedule> getScheduleList() {
        return scheduleList;
    }

    private List<Schedule> readListSchedules() {
        ScheduleXML scheduleXML = (ScheduleXML) FileUtils.readXMLFile(FILE_PATH, ScheduleXML.class);
        if (scheduleXML != null) {
            return scheduleXML.getScheduleList();
        }
        return new ArrayList<>();
    }

    private void writeListSchedules(List<Schedule> schedules) {
        ScheduleXML scheduleXML = new ScheduleXML();
        scheduleXML.setScheduleList(schedules);
        FileUtils.writeXMLtoFile(FILE_PATH, scheduleXML);
    }

    private boolean isPatientAvailable(Schedule newSchedule) {
        for (Schedule schedule : scheduleList) {
            if (schedule.getPatientId().equals(newSchedule.getPatientId())) {
                return false;
            }
        }
        return true;
    }

    private boolean isValidTimeRange(String timeRange) throws ParseException {
        String[] times = timeRange.split(" - ");
        Date startTime = timeFormat.parse(times[0]);
        Date endTime = timeFormat.parse(times[1]);
        return startTime.before(endTime);
    }

    public void add(Schedule schedule) throws IllegalArgumentException {
        try {
            if (!isValidTimeRange(schedule.getTime())) {
                throw new IllegalArgumentException("Thời gian bắt đầu phải nhỏ hơn thời gian kết thúc.");
            }
        } catch (ParseException e) {
            throw new IllegalArgumentException("Sai định dạng thời gian(hh:mm - hh:mm).");
        }

        if (!isPatientAvailable(schedule)) {
            throw new IllegalArgumentException("Bệnh nhân đã có lịch hẹn với một bác sĩ khác.");
        }

        scheduleList.add(schedule);
        writeListSchedules(scheduleList);
    }

    public void update(Schedule schedule) throws IllegalArgumentException {
        Schedule existingSchedule = null;
        for (Schedule s : scheduleList) {
            if (Objects.equals(s.getId(), schedule.getId())) {
                existingSchedule = s;
                break;
            }
        }
        if (existingSchedule == null) {
            throw new IllegalArgumentException("Lịch hẹn không tồn tại.");
        }

        try {
            if (!isValidTimeRange(schedule.getTime())) {
                throw new IllegalArgumentException("Thời gian bắt đầu phải nhỏ hơn thời gian kết thúc.");
            }
        } catch (ParseException e) {
            throw new IllegalArgumentException("Sai định dạng thời gian(hh:mm - hh:mm).");
        }

        if (!Objects.equals(existingSchedule.getPatientId(), schedule.getPatientId())) {
            if (!isPatientAvailable(schedule)) {
                throw new IllegalArgumentException("Bệnh nhân đã có lịch hẹn với một bác sĩ khác.");
            }
        }

        scheduleList.set(scheduleList.indexOf(existingSchedule), schedule);
        writeListSchedules(scheduleList);
    }

    public void delete(Schedule schedule) {
        scheduleList.removeIf(s -> Objects.equals(s.getId(), schedule.getId()));
        writeListSchedules(scheduleList);
    }
}
