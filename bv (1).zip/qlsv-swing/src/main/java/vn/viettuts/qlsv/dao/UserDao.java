package vn.viettuts.qlsv.dao;

import vn.viettuts.qlsv.entity.User;
import vn.viettuts.qlsv.entity.wrapper.UserXML;
import vn.viettuts.qlsv.utils.FileUtils;
import vn.viettuts.qlsv.utils.InitDb;

import java.util.ArrayList;
import java.util.List;

public class UserDao {
    private final String FILE_PATH = "src/main/resources/data/users.xml";
//    private final String FILE_PATH = InitDb.getFilePath("users.xml");
    private List<User> userList;

    public UserDao() {
        this.userList = readListUsers();
        if (userList == null) {
            userList = new ArrayList<>();
        }
        System.out.println(userList);
    }

    private List<User> readListUsers() {
        List<User> list = new ArrayList<>();

        UserXML userXML = (UserXML) FileUtils.readXMLFile(FILE_PATH, UserXML.class);
        if (userXML != null) {
            list = userXML.getUsers();
        }
        return list;
    }

    private void writeListUsers(List<User> users) {
        UserXML userXML = new UserXML();
        userXML.setUsers(users);
        FileUtils.writeXMLtoFile(FILE_PATH, userXML);
    }

    public boolean checkUser(User user) {
        for (User u : userList) {
            if (u.getUsername().equals(user.getUsername()) && u.getPassword().equals(user.getPassword())) {
                return true;
            }
        }
        return false;
    }


}
