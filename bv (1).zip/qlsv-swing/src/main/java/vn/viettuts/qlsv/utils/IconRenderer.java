package vn.viettuts.qlsv.utils;

import javax.swing.*;
import java.awt.*;

public class IconRenderer extends JLabel implements ListCellRenderer<String> {
    private final Icon[] icons;

    public IconRenderer(Icon[] icons) {
        this.icons = icons;
        setOpaque(true);
    }

    @Override
    public Component getListCellRendererComponent(JList<? extends String> list, String value, int index, boolean isSelected, boolean cellHasFocus) {
        setText(value);
        setIcon(icons[index]);

        if (isSelected) {
            setBackground(new Color(0, 120, 215));

        } else {
            setBackground(new Color(255, 255, 255));
            setForeground(list.getForeground());
        }

        return this;
    }
}
