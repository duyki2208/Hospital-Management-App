package vn.viettuts.qlsv.utils;

public class Regex {
    private static final String EMAIL = "[A-Za-z0-9+_.-]+@(.+)$";
    private static final String PHONE_NUMBER = "^(0[1-9]|84[1-9])[0-9]{8}$";
    private static final String DATE = "^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-(19[0-9]{2}|20[0-9]{2})$";
    private static final String POSITIVE_REAL_NUMBER_REGEX = "^[+]?([0-9]*[.])?[0-9]+$";
    private static final String DATE_TIME_PATTERN = "^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-\\d{4} ([01][0-9]|2[0-3]):([0-5][0-9])$"; // dd/mm/yyyy hh:mm
    private static final String TIME_RANGE_REGEX = "^([01]\\d|2[0-3]):([0-5]\\d) - ([01]\\d|2[0-3]):([0-5]\\d)$"; // hh:mm - hh:mm

    public static boolean isMatch(String type, String value) {
        switch (type) {
            case "email":
                return value.matches(EMAIL);
            case "phone":
                return value.matches(PHONE_NUMBER);
            case "date":
                return value.matches(DATE);
            case "dateTime":
                return value.matches(DATE_TIME_PATTERN);
            case "positiveRealNumber":
                return value.matches(POSITIVE_REAL_NUMBER_REGEX);
            case "time":
                return value.matches(TIME_RANGE_REGEX);

        }
        return false;
    }
}
