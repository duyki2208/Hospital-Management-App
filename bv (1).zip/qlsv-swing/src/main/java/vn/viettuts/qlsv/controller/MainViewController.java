package vn.viettuts.qlsv.controller;

import vn.viettuts.qlsv.view.LoginView;
import vn.viettuts.qlsv.view.MainView;

public class MainViewController {
    private final MainView mainView;

    public MainViewController(MainView mainView) {
        this.mainView = mainView;
        LoginView loginView = new LoginView();
        mainView.setLogoutItemAction(e -> {
            mainView.dispose();
            loginView.setVisible(true);
        });
    }

    public void showMainView() {
        mainView.setVisible(true);
    }
}
