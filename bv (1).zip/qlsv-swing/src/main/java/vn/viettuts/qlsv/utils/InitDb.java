package vn.viettuts.qlsv.utils;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class InitDb {
    private static List<String> xmlFilePaths = new ArrayList<>();

    public InitDb() {
        copyDatabaseFiles();
    }

    public void copyDatabaseFiles() {
        try {
            String tempDir = System.getProperty("java.io.tmpdir");
            Path tempDatabaseDir = Paths.get(tempDir, "data");

            if (Files.exists(tempDatabaseDir)) {
                boolean allFilesExist = true;
                try (InputStream jarStream = getClass().getProtectionDomain().getCodeSource().getLocation().openStream();
                     ZipInputStream zipStream = new ZipInputStream(jarStream)) {
                    ZipEntry entry;
                    while ((entry = zipStream.getNextEntry()) != null) {
                        if (entry.getName().startsWith("data/") && entry.getName().endsWith(".xml")) {
                            Path destination = Paths.get(tempDatabaseDir.toString(), entry.getName().substring("data/".length()));
                            if (!Files.exists(destination)) {
                                allFilesExist = false;
                                break;
                            }
                        }
                    }
                }

                if (allFilesExist) {
                    try (InputStream jarStream = getClass().getProtectionDomain().getCodeSource().getLocation().openStream();
                         ZipInputStream zipStream = new ZipInputStream(jarStream)) {
                        ZipEntry entry;
                        while ((entry = zipStream.getNextEntry()) != null) {
                            if (entry.getName().startsWith("data/") && entry.getName().endsWith(".xml")) {
                                Path destination = Paths.get(tempDatabaseDir.toString(), entry.getName().substring("data/".length()));
                                xmlFilePaths.add(destination.toString());
                            }
                        }
                    }
                    System.out.println("database is already copied to " + tempDatabaseDir.toString() + ". No need to copy again.");
                    return;
                }
            } else {
                Files.createDirectories(tempDatabaseDir);
            }

            try (InputStream jarStream = getClass().getProtectionDomain().getCodeSource().getLocation().openStream();
                 ZipInputStream zipStream = new ZipInputStream(jarStream)) {
                ZipEntry entry;
                while ((entry = zipStream.getNextEntry()) != null) {
                    if (entry.getName().startsWith("data/") && entry.getName().endsWith(".xml")) {
                        Path destination = Paths.get(tempDatabaseDir.toString(), entry.getName().substring("data/".length()));
                        File destFile = destination.toFile();
                        destFile.getParentFile().mkdirs();

                        try (OutputStream out = Files.newOutputStream(destFile.toPath())) {
                            byte[] buffer = new byte[1024];
                            int length;
                            while ((length = zipStream.read(buffer)) > 0) {
                                out.write(buffer, 0, length);
                            }
                        }

                        xmlFilePaths.add(destination.toString());
                        System.out.println("Copied " + entry.getName() + " into " + destination);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static String getFilePath(String fileName) {
        for (String path : xmlFilePaths) {
            if (path.endsWith(fileName)) {
                return path;
            }
        }
        return null;
    }
}
