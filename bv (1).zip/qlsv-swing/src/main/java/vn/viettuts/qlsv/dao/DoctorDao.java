package vn.viettuts.qlsv.dao;

import vn.viettuts.qlsv.entity.Doctor;
import vn.viettuts.qlsv.entity.wrapper.DoctorXML;
import vn.viettuts.qlsv.utils.FileUtils;
import vn.viettuts.qlsv.utils.InitDb;

import java.util.*;
import java.util.stream.Collectors;

public class DoctorDao {
    private final String FILE_PATH = "src/main/resources/data/doctors.xml";
    //    private final String FILE_PATH = InitDb.getFilePath("doctors.xml");
    private List<Doctor> doctorList;

    public List<Doctor> getDoctorList() {
        doctorList.sort(Comparator.comparing(Doctor::getId));
        return doctorList;
    }

    public DoctorDao() {
        this.doctorList = readListDoctors();
        if (doctorList == null) {
            doctorList = new ArrayList<>();
        }
        System.out.println(doctorList);
    }

    private List<Doctor> readListDoctors() {
        List<Doctor> list = new ArrayList<>();
        DoctorXML doctorXML = (DoctorXML) FileUtils.readXMLFile(FILE_PATH, DoctorXML.class);
        if (doctorXML != null) {
            list = doctorXML.getDoctors();
        }
        return list;
    }

    private void writeListDoctors(List<Doctor> doctors) {
        DoctorXML doctorXML = new DoctorXML();
        doctorXML.setDoctors(doctors);
        FileUtils.writeXMLtoFile(FILE_PATH, doctorXML);
    }

    private boolean isExistEmailOrPhone(Doctor doctorToCheck, boolean isUpdate) {
        for (Doctor doctor : doctorList) {

            if (isUpdate && doctor.getId().equals(doctorToCheck.getId())) {
                continue;
            }

            if (doctor.getEmail().equals(doctorToCheck.getEmail()) || doctor.getPhone().equals(doctorToCheck.getPhone()) || doctor.getId().equals(doctorToCheck.getId())) {
                return true;
            }
        }
        return false;
    }

    public void add(Doctor doctor) throws IllegalArgumentException {
        if (isExistEmailOrPhone(doctor, false)) {
            throw new IllegalArgumentException("Email hoặc số điện thoại hoặc mã đã tồn tại");
        }

        doctorList.add(doctor);
        writeListDoctors(doctorList);
    }

    public void update(Doctor doctor) throws IllegalArgumentException {
        if (isExistEmailOrPhone(doctor, true)) {
            throw new IllegalArgumentException("Email hoặc số điện thoại hoặc mã đã tồn tại");
        }

        for (Doctor d : doctorList) {
            if (Objects.equals(d.getId(), doctor.getId())) {
                doctorList.set(doctorList.indexOf(d), doctor);
                break;
            }
        }
        writeListDoctors(doctorList);
    }

    public void delete(Doctor doctorToDelete) {
        doctorList.removeIf(doctor -> Objects.equals(doctor.getId(), doctorToDelete.getId()));
        writeListDoctors(doctorList);
    }


    public List<Doctor> searchDoctors(Map<String, String> criteria) {
        return doctorList.stream().filter(doctor -> {
            boolean matches = true;
            for (Map.Entry<String, String> entry : criteria.entrySet()) {
                switch (entry.getKey()) {
                    case "id":
                        matches = doctor.getId().contains(entry.getValue());
                        break;
                    case "name":
                        matches = doctor.getName().contains(entry.getValue());
                        break;
                    case "dob":
                        matches = doctor.getDob().contains(entry.getValue());
                        break;
                    case "gender":
                        matches = doctor.getGender().equals(entry.getValue());
                        break;
                    case "email":
                        matches = doctor.getEmail().contains(entry.getValue());
                        break;
                    case "phone":
                        matches = doctor.getPhone().contains(entry.getValue());
                        break;
                    case "speciality":
                        matches = doctor.getSpeciality().contains(entry.getValue());
                        break;
                    case "degree":
                        matches = doctor.getDegree().contains(entry.getValue());
                        break;
                    default:
                        matches = false;
                }
                if (!matches) break;
            }
            return matches;
        }).collect(Collectors.toList());
    }

    public List<String> getAllDoctorIds() {
        List<String> doctorIds = new ArrayList<>();
        for (Doctor doctor : doctorList) {
            doctorIds.add(doctor.getId());
        }

        doctorIds.sort(Comparator.naturalOrder());
        return doctorIds;
    }

}
