package vn.viettuts.qlsv.controller;

import vn.viettuts.qlsv.dao.DoctorDao;
import vn.viettuts.qlsv.dao.PatientDao;
import vn.viettuts.qlsv.dao.ScheduleDao;
import vn.viettuts.qlsv.entity.Schedule;
import vn.viettuts.qlsv.utils.Regex;
import vn.viettuts.qlsv.view.ScheduleView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Optional;

public class ScheduleController {
    private final ScheduleView scheduleView;
    private final ScheduleDao scheduleDao;
    private final DoctorDao doctorDao;
    private final PatientDao patientDao;

    public ScheduleController(ScheduleView scheduleView) {
        this.scheduleView = scheduleView;
        scheduleDao = new ScheduleDao();
        doctorDao = new DoctorDao();
        patientDao = new PatientDao();

        scheduleView.setCbData(doctorDao.getAllDoctorIds(), patientDao.getAllPatientIds());
        scheduleView.setTableData(scheduleDao.getScheduleList());
        scheduleView.setScheduleId(scheduleDao.getScheduleList().size());

        scheduleView.setBtnAddAction(new AddScheduleListener());
        scheduleView.setBtnRefreshAction(new RefreshScheduleListener());
        scheduleView.setBtnUpdateAction(new UpdateScheduleListener());
        scheduleView.setBtnDeleteAction(new DeleteScheduleListener());

    }
//    private boolean isValidDate(String date){
//        return Regex.isMatch("dateTime", date);
//    }

    private boolean isValidTotalMoney(String totalMoney) {
        return Regex.isMatch("positiveRealNumber", totalMoney);
    }

    private boolean isValidTime(String time) {
        return Regex.isMatch("time", time);
    }

    class AddScheduleListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Optional<Schedule> schedule = Optional.ofNullable(scheduleView.getSchedule());
            if (schedule.isPresent()) {
//                if (!isValidDate(schedule.get().getDate())) {
//                    JOptionPane.showMessageDialog(scheduleView, "Sai định dạng ngày hẹn(dd-MM-yyyy HH:mm)");
//                    return;
//                }

                if (!isValidTotalMoney(schedule.get().getTotalMoney())) {
                    JOptionPane.showMessageDialog(scheduleView, "Tiền phải là số nguyên dương");
                    return;
                }

//                if (!isValidTime(schedule.get().getTime())) {
//                    JOptionPane.showMessageDialog(scheduleView, "Sai định dạng thời gian(hh:mm - hh:mm)");
//                    return;
//                }

                try {
                    scheduleDao.add(schedule.get());
                    scheduleView.setTableData(scheduleDao.getScheduleList());
                    JOptionPane.showMessageDialog(scheduleView, "Thêm lịch hẹn thành công");
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(scheduleView, ex.getMessage());
                }
            } else {
                JOptionPane.showMessageDialog(scheduleView, "Vui lòng nhập đầy đủ thông tin");
            }
        }
    }

    class UpdateScheduleListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Optional<Schedule> schedule = Optional.ofNullable(scheduleView.getSchedule());
            if (schedule.isPresent()) {
//                if (!isValidDate(schedule.get().getDate())) {
//                    JOptionPane.showMessageDialog(scheduleView, "Sai định dạng ngày hẹn(dd-MM-yyyy HH:mm)");
//                    return;
//                }

                if (!isValidTotalMoney(schedule.get().getTotalMoney())) {
                    JOptionPane.showMessageDialog(scheduleView, "Tiền phải là số nguyên dương");
                    return;
                }

//                if (!isValidTime(schedule.get().getTime())) {
//                    JOptionPane.showMessageDialog(scheduleView, "Sai định dạng thời gian(hh:mm - hh:mm)");
//                    return;
//                }
                try {
                    scheduleDao.update(schedule.get());
                    scheduleView.setTableData(scheduleDao.getScheduleList());
                    JOptionPane.showMessageDialog(scheduleView, "Cập nhật lịch hẹn thành công");
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(scheduleView, ex.getMessage());
                }
            } else {
                JOptionPane.showMessageDialog(scheduleView, "Vui lòng nhập đầy đủ thông tin");
            }
        }
    }

    class DeleteScheduleListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Optional<Schedule> schedule = Optional.ofNullable(scheduleView.getSchedule());
            if (schedule.isPresent()) {
                int input = JOptionPane.showConfirmDialog(scheduleView, "Bạn có chắc chắn muốn xóa bác sĩ này không?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
                if (input != 0) {
                    return;
                }
                try {
                    scheduleDao.delete(schedule.get());
                    scheduleView.setTableData(scheduleDao.getScheduleList());

                    scheduleView.clear(scheduleDao.getScheduleList().size());
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(scheduleView, ex.getMessage());
                }
            } else {
                JOptionPane.showMessageDialog(scheduleView, "Vui lòng chọn lịch hẹn cần xóa");
            }
        }
    }

    class RefreshScheduleListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            scheduleView.clear(scheduleDao.getScheduleList().size());
        }
    }


}
