package vn.viettuts.qlsv.entity;

import vn.viettuts.qlsv.utils.CalendarAdapter;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Schedule {
    private String id;
    private String doctorId;
    private String patientId;
    @XmlJavaTypeAdapter(CalendarAdapter.class)
    private Calendar date;
    private String content;
    private String time;
    private String totalMoney;

    public Schedule() {
    }

    public Schedule(String id, String doctorId, String patientId, Calendar date, String content, String time, String totalMoney) {
        this.id = id;
        this.doctorId = doctorId;
        this.patientId = patientId;
        this.date = date;
        this.content = content;
        this.time = time;
        this.totalMoney = totalMoney;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        return sdf.format(date.getTime());
    }

    public void setDate(Calendar date) {
        this.date = date;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(String totalMoney) {
        this.totalMoney = totalMoney;
    }

    @Override
    public String toString() {
        return "Schedule{" +
                "id='" + id + '\'' +
                ", doctorId='" + doctorId + '\'' +
                ", patientId='" + patientId + '\'' +
                ", date=" + getDate() +
                ", content='" + content + '\'' +
                ", time='" + time + '\'' +
                ", totalMoney='" + totalMoney + '\'' +
                '}';
    }
}
