package vn.viettuts.qlsv.controller;

import vn.viettuts.qlsv.dao.PatientDao;
import vn.viettuts.qlsv.entity.Patient;
import vn.viettuts.qlsv.utils.Regex;
import vn.viettuts.qlsv.view.PatientView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class PatientController {
    private final PatientDao patientDao;
    private final PatientView patientView;

    public PatientController(PatientView patientView) {
        this.patientDao = new PatientDao();
        this.patientView = patientView;

        patientView.setDataToTable(patientDao.getPatients());
        patientView.setPatientId(patientDao.getPatients().size());

        patientView.setBtnAdd(new AddPatientListener());
        patientView.setBtnUpdate(new UpdatePatientListener());
        patientView.setBtnDelete(new DeletePatientListener());
        patientView.setBtnRefresh(new RefreshPatientListener());
        patientView.setSearch(new SearchPatientListener());
    }

    private boolean validInput(Patient patient) {
        if(!Regex.isMatch("phone", patient.getPhone())) {
            JOptionPane.showMessageDialog(patientView, "Số điện thoại không hợp lệ");
            return true;
        }

        if(!Regex.isMatch("date", patient.getDob())) {
            JOptionPane.showMessageDialog(patientView, "Ngày sinh không hợp lệ(dd-MM-yyyy)");
            return true;
        }
        return false;
    }

    class AddPatientListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Optional<Patient> patient = Optional.ofNullable(patientView.getPatient());

            if(patient.isPresent()) {
                if (validInput(patient.get())) return;

                try {
                    patientDao.add(patient.get());
                    patientView.setDataToTable(patientDao.getPatients());
                    JOptionPane.showMessageDialog(patientView, "Thêm bệnh nhân thành công");
                    patientView.setPatientId(patientDao.getPatients().size());
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(patientView, ex.getMessage());
                }
            } else {
                JOptionPane.showMessageDialog(patientView, "Vui lòng nhập thông tin bệnh nhân");
            }
        }
    }



    class UpdatePatientListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Optional<Patient> patient = Optional.ofNullable(patientView.getPatient());

            if(patient.isPresent()) {
                if (validInput(patient.get())) return;

                try {
                    patientDao.update(patient.get());
                    patientView.setDataToTable(patientDao.getPatients());
                    JOptionPane.showMessageDialog(patientView, "Cập nhật thành công");
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(patientView, ex.getMessage());
                }
            } else {
                JOptionPane.showMessageDialog(patientView, "Vui lòng chọn bệnh nhân cần cập nhật");
            }
        }
    }

    class DeletePatientListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Optional<Patient> patient = Optional.ofNullable(patientView.getPatient());

            if(patient.isPresent()) {
                // xac nhan

                int input = JOptionPane.showConfirmDialog(patientView, "Bạn có chắc chắn muốn xóa bệnh nhân này không?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
                if(input != 0) return;
                patientDao.delete(patient.get());
                patientView.setDataToTable(patientDao.getPatients());
            } else {
                JOptionPane.showMessageDialog(patientView, "Vui lòng chọn bệnh nhân cần xóa");
            }
        }
    }

    class RefreshPatientListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            patientView.clear(patientDao.getPatients().size());
            patientView.setDataToTable(patientDao.getPatients());

        }
    }

    class SearchPatientListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Map<String, String> searchCriteria = patientView.getSearchCriteria();
            List<Patient> patientList = patientDao.searchPatient(searchCriteria);
            patientView.setDataToTable(patientList);
        }
    }


}
